# -*- coding: utf-8 -*-

import os
import re
from datetime import datetime

# Đường dẫn thư mục chứa các file kết quả
folder_path = "output_wifi"

# Khung giờ được phân chia
time_ranges = {
    "6h-12h": (6, 12),
    "12h-18h": (12, 18),
    "18h-0h": (18, 24),
    "0h-6h": (0, 6),
}

# Hàm phân loại khung giờ dựa trên giờ hiện tại
def get_time_range(hour):
    for key, (start, end) in time_ranges.items():
        if start <= hour < end:
            return key
    return "0h-6h" if hour < 6 else "18h-0h"

# Hàm tính throughput từ file iperf3 (giả sử giá trị throughput nằm ở dòng chứa "bits/sec")
def parse_throughput(file_path):
    with open(file_path, 'r') as file:
        for line in file:
            match = re.search(r'(\d+\.\d+|\d+)\s+(Mbits/sec|Kbits/sec)', line)
            if match:
                value, unit = match.groups()
                value = float(value)
                if unit == 'Kbits/sec':
                    value /= 1000  # chuyển Kbits/sec thành Mbits/sec
                return value
    return None

# Đọc tất cả các file trong thư mục và tính throughput trung bình theo khung giờ
def calculate_average_throughput():
    throughput_data = {key: [] for key in time_ranges.keys()}

    for file_name in os.listdir(folder_path):
        if file_name.startswith("wifi_") and file_name.endswith(".txt"):
            file_path = os.path.join(folder_path, file_name)

            # Lấy timestamp từ tên file
            timestamp_str = file_name.replace('wifi_', '').replace('.txt', '')
            try:
                timestamp = datetime.strptime(timestamp_str, "%Y-%m-%d_%H-%M")
            except ValueError:
                print("Bỏ qua file {} do định dạng thời gian không hợp lệ".format(file_name))
                continue

            time_range = get_time_range(timestamp.hour)

            # Parse throughput từ file
            throughput = parse_throughput(file_path)
            if throughput is not None:
                throughput_data[time_range].append(throughput)

    # Tính throughput trung bình cho mỗi khung giờ
    for time_range, values in throughput_data.items():
        if values:
            avg_throughput = sum(values) / len(values)
            print("Throughput trung bình từ {}: {:.2f} Mbits/sec".format(time_range, avg_throughput))
        else:
            print("Không có dữ liệu cho khung giờ {}".format(time_range))

if __name__ == "__main__":
    calculate_average_throughput()
