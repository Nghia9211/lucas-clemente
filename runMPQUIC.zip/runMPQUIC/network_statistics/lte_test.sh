#!/bin/bash

# Khai báo địa chỉ IP
CLIENT_IP="192.168.8.182"
SERVER_IP="171.244.134.9"

mkdir -p output_lte

trap "echo 'Terminating script...'; exit" SIGINT SIGTERM

while true; do
    cur_time=$(date +"%Y-%m-%d_%H-%M")

    # Kiểm tra nếu thời gian hiện tại là x:00 hoặc x:30
    current_minute=$(date +"%M")
    if [ "$current_minute" == "30" ] || [ "$current_minute" == "30" ]; then
        # Đo băng thông với iperf3
        iperf3 -c "$SERVER_IP" -B "$CLIENT_IP" -R >> "output_lte/lte_${cur_time}.txt" 2>> "output_lte/error_log.txt"
        if [ $? -ne 0 ]; then
            echo "$cur_time: iperf3 command failed" >> "output_lte/error_log.txt"
        fi

        # Đo RTT bằng ping trong 5 phút
        echo "Starting RTT measurement using ping..."
        ping -I "$CLIENT_IP" -c 300 "$SERVER_IP" >> "output_lte/rtt_${cur_time}.txt" 2>> "output_lte/error_log.txt"
        if [ $? -ne 0 ]; then
            echo "$cur_time: ping command failed" >> "output_lte/error_log.txt"
        fi

        # Đo packet loss với iperf3 UDP
        echo "Starting packet loss measurement using iperf3 UDP..."
        iperf3 -c "$SERVER_IP" -B "$CLIENT_IP" -u -b 24M -R >> "output_lte/udp_loss_${cur_time}.txt" 2>> "output_lte/error_log.txt"
        if [ $? -ne 0 ]; then
            echo "$cur_time: iperf3 UDP command failed" >> "output_lte/error_log.txt"
        fi
    fi

    # Chờ 30 giây trước khi kiểm tra lại thời gian
    sleep 30
done
