# -*- coding: utf-8 -*-

import os
import re
from datetime import datetime
import numpy as np

# Đường dẫn thư mục chứa các file kết quả RTT
folder_path = "output_lte"

# Khung giờ được phân chia
time_ranges = {
    "6h-12h": (6, 12),
    "12h-18h": (12, 18),
    "18h-0h": (18, 24),
    "0h-6h": (0, 6),
}

# Hàm phân loại khung giờ dựa trên giờ hiện tại
def get_time_range(hour):
    for key, (start, end) in time_ranges.items():
        if start <= hour < end:
            return key
    return "0h-6h" if hour < 6 else "18h-0h"

# Hàm phân tích giá trị RTT từ file ping
def parse_rtt(file_path):
    rtt_values = []
    with open(file_path, 'r') as file:
        for line in file:
            # Tìm các giá trị RTT trong dòng chứa "time="
            match = re.search(r'time=(\d+\.\d+)', line)
            if match:
                rtt_values.append(float(match.group(1)))  # Lưu giá trị RTT
    return rtt_values

# Đọc tất cả các file RTT và tính toán giá trị RTT trung bình và phương sai theo khung giờ
def calculate_rtt_stats_by_time_range():
    rtt_data_by_range = {key: [] for key in time_ranges.keys()}

    for file_name in os.listdir(folder_path):
        if file_name.startswith("rtt_") and file_name.endswith(".txt"):
            file_path = os.path.join(folder_path, file_name)
            
            # Lấy timestamp từ tên file (giả sử tên file có định dạng "rtt_YYYY-MM-DD_HH-MM.txt")
            timestamp_match = re.search(r'\d{4}-\d{2}-\d{2}_\d{2}-\d{2}', file_name)
            if timestamp_match:
                timestamp_str = timestamp_match.group()
                try:
                    timestamp = datetime.strptime(timestamp_str, "%Y-%m-%d_%H-%M")
                except ValueError:
                    print("Bỏ qua file {} do định dạng thời gian không hợp lệ".format(file_name))
                    continue

                time_range = get_time_range(timestamp.hour)

                # Parse RTT từ file
                rtt_values = parse_rtt(file_path)
                if rtt_values:
                    rtt_data_by_range[time_range].extend(rtt_values)

    # Tính RTT trung bình và phương sai cho mỗi khung giờ
    for time_range, rtt_values in rtt_data_by_range.items():
        if rtt_values:
            mean_rtt = np.mean(rtt_values)
            variance_rtt = np.var(rtt_values)
            print("RTT trung bình từ {}: {:.2f} ms".format(time_range, mean_rtt))
            print("Phương sai RTT từ {}: {:.2f} ms^2".format(time_range, variance_rtt))
        else:
            print("Không có dữ liệu cho khung giờ {}".format(time_range))

if __name__ == "__main__":
    calculate_rtt_stats_by_time_range()
