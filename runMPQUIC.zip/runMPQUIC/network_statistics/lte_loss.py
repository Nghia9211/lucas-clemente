# -*- coding: utf-8 -*-

import os
import re
from datetime import datetime

# Đường dẫn thư mục chứa các file kết quả UDP
folder_path = "output_lte"

# Khung giờ được phân chia
time_ranges = {
    "6h-12h": (6, 12),
    "12h-18h": (12, 18),
    "18h-0h": (18, 24),
    "0h-6h": (0, 6),
}

# Hàm phân loại khung giờ dựa trên giờ hiện tại
def get_time_range(hour):
    for key, (start, end) in time_ranges.items():
        if start <= hour < end:
            return key
    return "0h-6h" if hour < 6 else "18h-0h"

# Hàm phân tích giá trị mất gói tin từ file UDP
def parse_loss(file_path):
    total_lost = 0
    total_datagrams = 0
    with open(file_path, 'r') as file:
        for line in file:
            # Tìm dòng chứa thông tin về số gói tin bị mất (Lost/Total Datagrams)
            match = re.search(r'(\d+)/(\d+) \(\d+%\) ', line)
            if match:
                lost_packets = int(match.group(1))
                total_packets = int(match.group(2))
                total_lost += lost_packets
                total_datagrams += total_packets

    if total_datagrams > 0:
        return (total_lost / total_datagrams) * 100  # Tính tỷ lệ mất gói tin (percentage)
    return None

# Đọc tất cả các file UDP và tính toán tỷ lệ mất gói tin theo khung giờ
def calculate_loss_by_time_range():
    loss_data_by_range = {key: [] for key in time_ranges.keys()}

    for file_name in os.listdir(folder_path):
        if file_name.startswith("udp_") and file_name.endswith(".txt"):
            file_path = os.path.join(folder_path, file_name)
            
            # Lấy timestamp từ tên file (giả sử tên file có định dạng "udp_YYYY-MM-DD_HH-MM.txt")
            timestamp_match = re.search(r'\d{4}-\d{2}-\d{2}_\d{2}-\d{2}', file_name)
            if timestamp_match:
                timestamp_str = timestamp_match.group()
                try:
                    timestamp = datetime.strptime(timestamp_str, "%Y-%m-%d_%H-%M")
                except ValueError:
                    print("Bỏ qua file {} do định dạng thời gian không hợp lệ".format(file_name))
                    continue

                time_range = get_time_range(timestamp.hour)

                # Parse loss từ file
                loss_percentage = parse_loss(file_path)
                if loss_percentage is not None:
                    loss_data_by_range[time_range].append(loss_percentage)

    # Tính tỷ lệ mất gói tin trung bình cho mỗi khung giờ
    for time_range, loss_values in loss_data_by_range.items():
        if loss_values:
            avg_loss = sum(loss_values) / len(loss_values)
            print("Tỷ lệ mất gói tin trung bình từ {}: {:.2f}%".format(time_range, avg_loss))
        else:
            print("Không có dữ liệu cho khung giờ {}".format(time_range))

if __name__ == "__main__":
    calculate_loss_by_time_range()
